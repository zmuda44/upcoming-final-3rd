// create the Stack class with two methods to remove and add an element
class Stack {
  
}

module.exports = Stack;
