// TODO: Add a comment explaining what a react component is
function HelloReact() {
  const text = 'some text';

  // TODO: Add a comment explaining what JSX is and the significance of the curly braces
  return <h2>Hello World! Here is {text}</h2>;
}

export default HelloReact;
