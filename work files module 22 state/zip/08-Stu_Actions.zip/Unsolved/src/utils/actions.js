export const ADD_STUDENT = 'ADD_STUDENT';

export const REMOVE_STUDENT = 'REMOVE_STUDENT';

export const UPDATE_STUDENT = 'UPDATE_STUDENT';

export const ADD_MAJOR = 'ADD_MAJOR';

export const REMOVE_MAJOR = 'REMOVE_MAJOR';
