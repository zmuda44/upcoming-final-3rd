const School = require('./School');
const Class = require('./Class');
const Professor = require('./Professor');

module.exports = { School, Class, Professor };
