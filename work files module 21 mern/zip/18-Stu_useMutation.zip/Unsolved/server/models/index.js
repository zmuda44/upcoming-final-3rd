const Thought = require('./Thought');

module.exports = { Thought };
