# 📐 Add Comments to Implementation of JWT Signing

Work with a partner to add comments that describe the functionality of the code found in [resolvers.js](./Unsolved/schemas/resolvers.js).

---

## 🏆 Bonus

If you have completed this activity, work through the following challenge with your partner to further your knowledge:

* What are the pros and cons of using JSON Web Tokens?

Use [Google](https://www.google.com) or another search engine to research this.

---
© 2024 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
