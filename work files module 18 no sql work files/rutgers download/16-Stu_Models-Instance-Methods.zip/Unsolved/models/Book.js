const mongoose = require('mongoose');

// TODO: Define a new schema named `bookSchema`

// TODO: Create a custom instance method named `getDiscount`

// TODO: Create a model named `Book`

// TODO: Create a new instance of the model

// TODO: Call the custom instance method on the instance

module.exports = Book;
