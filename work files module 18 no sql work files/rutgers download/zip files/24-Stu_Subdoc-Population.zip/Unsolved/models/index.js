const Tags = require('./Tags');
const Post = require('./Post');

module.exports = { Tags, Post };
