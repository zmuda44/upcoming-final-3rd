const Genre = require('./Genre');

module.exports = { Genre };
