const User = require('./User');
const Tag = require('./Tag');
const Application = require('./Application');

module.exports = { User, Application, Tag };
